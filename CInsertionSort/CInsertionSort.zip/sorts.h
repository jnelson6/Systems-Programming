#ifndef SORTS_H_
#define SORTS_H_

/* Function prototypes */
void insertion_sort(int *array, const int length);
void display_array(int *array, const int length);

#endif
