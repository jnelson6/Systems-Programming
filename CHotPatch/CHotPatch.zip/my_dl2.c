#include <stdio.h>

void my_fn() {
    printf("Look! It's the new function.\n");
}
